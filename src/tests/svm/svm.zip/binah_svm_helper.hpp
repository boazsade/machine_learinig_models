//
//  binah_svm_helper.hpp
//  SVTests
//
//  Created by Konstantin Gedalin on 29/04/2018.
//  Copyright © 2018 binah.ai. All rights reserved.
//


#pragma once
#include <iostream>
#include <opencv/cxcore.hpp>


using namespace std;
using namespace cv;

class Model {
    static void silent(const char *) {};
    static svm_node *make_node(const cv::Mat &A, int r=0);
    svm_model *model;
    svm_problem prob;
    svm_parameter param = {C_SVC,
        RBF,
        3,    /* for poly */
        0.1,    /* for poly/rbf/sigmoid */
        0,    /* for poly/sigmoid */
        /* these are for training only */
        100, /* in MB */
        0.001,    /* stopping criteria */
        1.0,    /* for C_SVC, EPSILON_SVR and NU_SVR */
        0,        /* for C_SVC */
        NULL,    /* for C_SVC */
        NULL,        /* for C_SVC */
        0.5,    /* for NU_SVC, ONE_CLASS, and NU_SVR */
        0.1,    /* for EPSILON_SVR */
        0,    /* use the shrinking heuristics */
        1 /* do probability estimates */};
public:
    
    Model(const std::string &filename);
    Model(const cv::Mat &A, const cv::Mat &L);
    Model(const std::vector<std::vector<float>> &A, const std::vector<float> &L);
    ~Model();
    void   probability(const cv::Mat &query, Mat &result);
    double predict(const cv::Mat &query);
    bool   save(const std::string &filename);
    /** Type of a %SVM formulation.
     See SVM::Types. Default value is SVM::C_SVC. */
    /** @see setType */
     int getType() const ;
    /** @copybrief getType @see getType */
     void setType(int val) ;
    
    /** Parameter \f$\gamma\f$ of a kernel function.
     For SVM::POLY, SVM::RBF, SVM::SIGMOID or SVM::CHI2. Default value is 1. */
    /** @see setGamma */
     double getGamma() const ;
    /** @copybrief getGamma @see getGamma */
     void setGamma(double val) ;
    
    /** Parameter _coef0_ of a kernel function.
     For SVM::POLY or SVM::SIGMOID. Default value is 0.*/
    /** @see setCoef0 */
     double getCoef0() const ;
    /** @copybrief getCoef0 @see getCoef0 */
     void setCoef0(double val) ;
    
    /** Parameter _degree_ of a kernel function.
     For SVM::POLY. Default value is 0. */
    /** @see setDegree */
     double getDegree() const ;
    /** @copybrief getDegree @see getDegree */
     void setDegree(double val) ;
    
    /** Parameter _C_ of a %SVM optimization problem.
     For SVM::C_SVC, SVM::EPS_SVR or SVM::NU_SVR. Default value is 0. */
    /** @see setC */
     double getC() const ;
    /** @copybrief getC @see getC */
     void setC(double val) ;
    
    /** Parameter \f$\nu\f$ of a %SVM optimization problem.
     For SVM::NU_SVC, SVM::ONE_CLASS or SVM::NU_SVR. Default value is 0. */
    /** @see setNu */
     double getNu() const ;
    /** @copybrief getNu @see getNu */
     void setNu(double val) ;
    
    /** Parameter \f$\epsilon\f$ of a %SVM optimization problem.
     For SVM::EPS_SVR. Default value is 0. */
    /** @see setP */
     double getP() const ;
    /** @copybrief getP @see getP */
     void setP(double val) ;
    
    /** Optional weights in the SVM::C_SVC problem, assigned to particular classes.
     They are multiplied by _C_ so the parameter _C_ of class _i_ becomes `classWeights(i) * C`. Thus
     these weights affect the misclassification penalty for different classes. The larger weight,
     the larger penalty on misclassification of data from the corresponding class. Default value is
     empty Mat. */
    /** @see setClassWeights */
    // cv::Mat getClassWeights() const ;
    /** @copybrief getClassWeights @see getClassWeights */
   //  void setClassWeights(const cv::Mat &val) ;
    
    /** Termination criteria of the iterative %SVM training procedure which solves a partial
     case of constrained quadratic optimization problem.
     You can specify tolerance and/or the maximum number of iterations. Default value is
     `TermCriteria( TermCriteria::MAX_ITER + TermCriteria::EPS, 1000, FLT_EPSILON )`; */
    /** @see setTermCriteria */
     double getTermCriteria() const ;
    /** @copybrief getTermCriteria @see getTermCriteria */
     void setTermCriteria(const double &val) ;
    
    /** Type of a %SVM kernel.
     See SVM::KernelTypes. Default value is SVM::RBF. */
     int getKernelType() const ;
    
    /** Initialize with one of predefined kernels.
     See SVM::KernelTypes. */
     void setKernel(int kernelType) ;

    
};
