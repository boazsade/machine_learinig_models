//
//  binah_svm_helper.cpp
//  SVTests
//
//  Created by Konstantin Gedalin on 29/04/2018.
//  Copyright © 2018 binah.ai. All rights reserved.
//
#include <ctype.h>
#include <stdlib.h>
#include <vector>
#include <iostream>
#include <algorithm>
#include <iomanip>
#include <numeric>
#include <opencv/cxcore.hpp>
#include <opencv2/core/core.hpp>
#include "svm.h"
#include "binah_svm_helper.hpp"
#define Malloc(type,n) (type *)malloc((n)*sizeof(type))
Model::Model(const std::string &filename) {
    model = svm_load_model(filename.c_str());
    CV_Assert(model != 0);
    prob.l=0;
}
svm_node *Model::make_node(const Mat &A, int r) { // for a single row opencv feature
    const float *dataPtr = A.ptr<float>(r); // Get data from OpenCV Mat
    svm_node *x_space = Malloc(svm_node, A.cols+1); // one more for the terminator
    for (int c=0; c<A.cols; c++) {
        x_space[c].index = c+1;  // Index starts from 1; Pre-computed kernel starts from 0
        x_space[c].value = dataPtr[c];
    }
    x_space[A.cols].index = -1;  // End of sequence
    return x_space;
}
Model::Model(const Mat &A, const Mat &L) {
    svm_set_print_string_function(silent); // comment to see the debug output
   
    prob.l = A.rows;
    prob.y = Malloc(double, prob.l);
    prob.x = Malloc(svm_node *, prob.l);
    for (int r=0; r<prob.l; r++) {
        prob.x[r] = make_node(A, r);
        prob.y[r] = L.at<int>(r, 0);
    }
    model = svm_train(&prob, &param);
}

Model::~Model() {
    // fixme: if i ever *use* an svm_problem (it's ok with a model loaded from file),
    //   i can't release it after training, but have to keep it around
    //   for the lifetime of the model (s.a. svm.h:69), why ?
    if (prob.l) { // no need to do anything, if model was loaded from file
        for (int r=0; r<prob.l; r++) free(prob.x[r]);
        free(prob.x);
        free(prob.y);
    }
    svm_free_and_destroy_model(&model);
}

void Model::probability(const Mat &query, Mat &result) {
    vector<double> prob_est(model->nr_class,0);
    svm_node *x = make_node(query);
    double prediction =svm_predict_probability(model, x, prob_est.data());
    free(x);
    result.push_back(prediction);
    for(int i=0;i<prob_est.size();++i)
    result.push_back(prob_est[i]);
    
    
}

double Model::predict(const Mat &query) { // a row sample
    svm_node *x = make_node(query);
    double prediction = svm_predict(model, x);
    free(x);
    return prediction;
}

bool Model::save(const std::string &filename) {
    int res=svm_save_model(filename.c_str(), model);
    if(res==-1) return false;
    return true;
    }
int Model::getType() const
{
    return param.svm_type;
    
}

/** @copybrief getType @see getType */
void Model::setType(int val)
{
    param.svm_type=val;
    
}

/** Parameter \f$\gamma\f$ of a kernel function.
 For SVM::POLY, SVM::RBF, SVM::SIGMOID or SVM::CHI2. Default value is 1. */
/** @see setGamma */
double Model::getGamma() const
{
    return param.gamma;
    
}
/** @copybrief getGamma @see getGamma */
void Model::setGamma(double val)
{
    param.gamma=val;
    
}

/** Parameter _coef0_ of a kernel function.
 For SVM::POLY or SVM::SIGMOID. Default value is 0.*/
/** @see setCoef0 */
double Model::getCoef0() const
{
    return param.coef0;
    
}
/** @copybrief getCoef0 @see getCoef0 */
void Model::setCoef0(double val)
{
    
    param.coef0=val;
    
}

/** Parameter _degree_ of a kernel function.
 For SVM::POLY. Default value is 0. */
/** @see setDegree */
double Model::getDegree() const
{
    return param.degree;
    
}
/** @copybrief getDegree @see getDegree */
void Model::setDegree(double val)
{
    param.degree=val;
    
}

/** Parameter _C_ of a %SVM optimization problem.
 For SVM::C_SVC, SVM::EPS_SVR or SVM::NU_SVR. Default value is 0. */
/** @see setC */
double Model::getC() const
{
    return param.C;
    
    
}
/** @copybrief getC @see getC */
void Model::setC(double val)
{
    param.C=val;
    
}

/** Parameter \f$\nu\f$ of a %SVM optimization problem.
 For SVM::NU_SVC, SVM::ONE_CLASS or SVM::NU_SVR. Default value is 0. */
/** @see setNu */
double Model::getNu() const{
    return param.nu;
    
}
/** @copybrief getNu @see getNu */
void Model::setNu(double val)
{
    param.nu=val;
}

/** Parameter \f$\epsilon\f$ of a %SVM optimization problem.
 For SVM::EPS_SVR. Default value is 0. */
/** @see setP */
double Model::getP() const
{
    return param.p;
    
}
/** @copybrief getP @see getP */
void Model::setP(double val)
{
    param.p=val;
    
}

/** Optional weights in the SVM::C_SVC problem, assigned to particular classes.
 They are multiplied by _C_ so the parameter _C_ of class _i_ becomes `classWeights(i) * C`. Thus
 these weights affect the misclassification penalty for different classes. The larger weight,
 the larger penalty on misclassification of data from the corresponding class. Default value is
 empty Mat. */
/** @see setClassWeights */
//cv::Mat Model::getClassWeights() const ;
/** @copybrief getClassWeights @see getClassWeights */
//void Model::setClassWeights(const cv::Mat &val) ;

/** Termination criteria of the iterative %SVM training procedure which solves a partial
 case of constrained quadratic optimization problem.
 You can specify tolerance and/or the maximum number of iterations. Default value is
 `TermCriteria( TermCriteria::MAX_ITER + TermCriteria::EPS, 1000, FLT_EPSILON )`; */
/** @see setTermCriteria */
double Model::getTermCriteria() const
{
    return param.eps;
}
/** @copybrief getTermCriteria @see getTermCriteria */
void Model::setTermCriteria(const double &val)
{
    param.eps=val;
}

/** Type of a %SVM kernel.
 See SVM::KernelTypes. Default value is SVM::RBF. */
int Model::getKernelType() const {
    return param.kernel_type;
}

/** Initialize with one of predefined kernels.
 See SVM::KernelTypes. */
void Model::setKernel(int kernelType)
{
    param.kernel_type=kernelType;
}

