
#include <algorithm>
#include <iomanip>
#include <numeric>
#include <opencv/cxcore.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/ml/ml.hpp>
#include <iostream>
#include <vector>
#include "svm.h"
#include <ctype.h>
#include <stdlib.h>
#include <vector>
#include <iostream>
#include "binah_svm_helper.hpp"
using namespace std;
using namespace cv;
using namespace cv::ml;

#define Malloc(type,n) (type *)malloc((n)*sizeof(type))

struct svm_parameter param;        // set by parse_command_line
struct svm_problem prob;        // set by read_problem
struct svm_model *model;
struct svm_node *x_space;

vector<int> generateLabels(int labelsSize)
{
    std::vector<int> labels;
    for (int i=0; i<labelsSize; ++i)
    {
        labels.push_back(i%2+1);
    }
    return labels;
}

vector<vector<double> > generateData(int problemSize, int featureNum)
{
    std::vector<std::vector<double> > data;
    for (int i=0; i<problemSize; ++i)
    {
        std::vector<double> featureSet;
        for (int j=0; j<featureNum; ++j)
        {
            cout<<"feature pushed"<<endl;
            featureSet.push_back(j);
        }
        data.push_back(featureSet);
    }
    return data;
}






int test_orig()
{
    //here I will create a small artificial problem just for illustration
    int sizeOfProblem = 10; //number of lines with labels
    int elements = 2; //number of features for each data vector
    
    vector<int> labels = { 0, 0, 1, 1, 0, 2, 1, 2, 1, 0 };
    vector<vector<double> > data =  { { 100, 10 }, { 150, 10 }, { 600, 200 }, { 600, 10 }, { 10, 100 }, { 455, 10 }, { 345, 255 }, { 10, 501 }, { 401, 255 }, { 30, 150 } };
    vector<vector<float> > dataf = { { 100, 10 }, { 150, 10 }, { 600, 200 }, { 600, 10 }, { 10, 100 }, { 455, 10 }, { 345, 255 }, { 10, 501 }, { 401, 255 }, { 30, 150 } };
    
    
    cout<<"data size = "<<data.size()<<endl;
    cout<<"labels size = "<<labels.size()<<endl;
    //initialize the size of the problem with just an int
    prob.l = sizeOfProblem;
    //here we need to give some memory to our structures
    // @param prob.l = number of labels
    // @param elements = number of features for each label
    prob.y = Malloc(double,prob.l); //space for prob.l doubles
    prob.x = Malloc(struct svm_node *, prob.l); //space for prob.l pointers to struct svm_node
    x_space = Malloc(struct svm_node, (elements+1) * prob.l); //memory for pairs of index/value
    
    //here we are going to initialize it all a bit
    
    
    //initialize the different lables with an array of labels
    for (int i=0; i < prob.l; ++i)
    {
        prob.y[i] = labels[i];
        cout<<"prob.y["<<i<<"] = "<<prob.y[i]<<endl;
    }
    //initialize the svm_node vector with input data array as follows:
    int j=0; //counter to traverse x_space[i];
    for (int i=0;i < prob.l; ++i)
    {
        //set i-th element of prob.x to the address of x_space[j].
        //elements from x_space[j] to x_space[j+data[i].size] get filled right after next line
        prob.x[i] = &x_space[j];
        for (int k=0; k<data[i].size(); ++k, ++j)
        {
            x_space[j].index=k+1; //index of value
            x_space[j].value=data[i][k]; //value
            cout<<"x_space["<<j<<"].index = "<<x_space[j].index<<endl;
            cout<<"x_space["<<j<<"].value = "<<x_space[j].value<<endl;
        }
        x_space[j].index=-1;//state the end of data vector
        x_space[j].value=0;
        cout<<"x_space["<<j<<"].index = "<<x_space[j].index<<endl;
        cout<<"x_space["<<j<<"].value = "<<x_space[j].value<<endl;
        j++;
        
    }
    
    //ok, let's try to print it
    for (int i = 0; i < prob.l; ++i)
    {
        cout<<"line "<<i<<endl;
        cout<<prob.y[i]<<"---";
        for (int k = 0; k < elements; ++k)
        {
            int index = (prob.x[i][k].index);
            double value = (prob.x[i][k].value);
            cout<<index<<":"<<value<<" ";
        }
        cout<<endl;
    }
    cout<<"all ok"<<endl;
    
    //set all default parameters for param struct
    param.svm_type = C_SVC;
    param.kernel_type = RBF;
    param.degree = 3;
    param.gamma = 0.1;//(double)1/(double)elements;
    param.coef0 = 0;
    param.nu = 0.5;
    param.cache_size = 100;
    param.C = 1;
    param.eps = 1e-3;
    param.p = 0.1;
    param.shrinking = 0;
    param.probability = 1;
    param.nr_weight = 0;
    param.weight_label = NULL;
    param.weight = NULL;
    
    //try to actually execute it
    model = svm_train(&prob, &param);
    svm_save_model("libsvmsvm.txt", model);
  
    return 0;
}



int main(int argc, char **argv)
{   // demo, opencv like data
  //  test_orig();
    vector<int> labels = { 0, 0, 1, 1, 0, 2, 1, 2, 1, 0 };
    vector<vector<float> > dataf = { { 100, 10 }, { 150, 10 }, { 600, 200 }, { 600, 10 }, { 10, 100 }, { 455, 10 }, { 345, 255 }, { 10, 501 }, { 401, 255 }, { 30, 150 } };
    
    Mat A = cv::Mat::zeros((int)dataf.size(),(int)dataf[0].size(),CV_32F);
    for(int i=0;i <A.rows;++i)
    {
        for(int j=0;j <A.cols;++j)
            A.at<float>(i,j)=dataf[i][j];
        
    }
    
    Mat L = Mat((int)labels.size(),1,CV_32S,labels.data());
    
    
    Model model(A,L); // from opencv data
    model.save("5x5.txt");
    //Model model("5x5.txt"); // or load from file (e.g. from svm-train)
    for (int r=A.rows-1; r>=0; r--) { // backwards, for a change ;)
        Mat result;
        model.probability(A.row(r), result); // prediction, probA, probB
       // cerr << "prob " << r+1 << " " << result.t() << endl;
        double prediction = model.predict(A.row(r));
        cerr << "pred " << r+1 << " " << prediction << endl;
    }
    return 0;
}


